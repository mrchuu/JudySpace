--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "JudySpace";
--
-- Name: JudySpace; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "JudySpace" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "JudySpace" OWNER TO postgres;

\connect "JudySpace"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: blog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog (
    blog_id integer NOT NULL,
    title character varying NOT NULL,
    blog_thumbnail character varying NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean DEFAULT false,
    deleted_date timestamp with time zone,
    update_date timestamp with time zone,
    category_id integer NOT NULL,
    tag_id integer,
    caption character varying,
    youtube_link character varying
);


ALTER TABLE public.blog OWNER TO postgres;

--
-- Name: COLUMN blog.blog_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.blog.blog_id IS 'containing blogs about some random things, movie, or book';


--
-- Name: COLUMN blog.youtube_link; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.blog.youtube_link IS 'if the blog talks about films, it has a link that leads to
            its trailer';


--
-- Name: blog_blog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_blog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_blog_id_seq OWNER TO postgres;

--
-- Name: blog_blog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_blog_id_seq OWNED BY public.blog.blog_id;


--
-- Name: blog_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_category (
    id integer NOT NULL,
    name character varying
);


ALTER TABLE public.blog_category OWNER TO postgres;

--
-- Name: blog_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_category_id_seq OWNER TO postgres;

--
-- Name: blog_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_category_id_seq OWNED BY public.blog_category.id;


--
-- Name: blog_movie_catgory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_movie_catgory (
    blog_id integer NOT NULL,
    movie_category_id integer NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.blog_movie_catgory OWNER TO postgres;

--
-- Name: blog_upvote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_upvote (
    blog_id integer NOT NULL,
    user_id integer NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.blog_upvote OWNER TO postgres;

--
-- Name: blog_upvote_blog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_upvote_blog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_upvote_blog_id_seq OWNER TO postgres;

--
-- Name: blog_upvote_blog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_upvote_blog_id_seq OWNED BY public.blog_upvote.blog_id;


--
-- Name: blog_upvote_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_upvote_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blog_upvote_user_id_seq OWNER TO postgres;

--
-- Name: blog_upvote_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_upvote_user_id_seq OWNED BY public.blog_upvote.user_id;


--
-- Name: blogtag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blogtag (
    id integer NOT NULL,
    name character varying,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_delete boolean DEFAULT false,
    delete_date timestamp with time zone,
    updated_date timestamp with time zone
);


ALTER TABLE public.blogtag OWNER TO postgres;

--
-- Name: blogtag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blogtag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.blogtag_id_seq OWNER TO postgres;

--
-- Name: blogtag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blogtag_id_seq OWNED BY public.blogtag.id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment (
    user_id integer,
    content text,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_root boolean DEFAULT true,
    blog_id integer,
    comment_rep_id integer,
    comment_id integer NOT NULL,
    is_delete boolean DEFAULT false,
    delete_date timestamp with time zone,
    update_date timestamp with time zone
);


ALTER TABLE public.comment OWNER TO postgres;

--
-- Name: COLUMN comment.blog_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.comment.blog_id IS 'if the comment is root, then it is a comment to a blog';


--
-- Name: COLUMN comment.comment_rep_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.comment.comment_rep_id IS 'if is not a root, then it is a reply to another comment';


--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comment_id_seq OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comment_id_seq OWNED BY public.comment.comment_id;


--
-- Name: comment_upvote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comment_upvote (
    user_id integer NOT NULL,
    comment_id integer NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.comment_upvote OWNER TO postgres;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Name: movie_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movie_category (
    movie_category_id integer NOT NULL,
    catogory_name character varying,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_date timestamp with time zone,
    delete_date timestamp with time zone,
    is_deleted boolean DEFAULT false
);


ALTER TABLE public.movie_category OWNER TO postgres;

--
-- Name: movie_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.movie_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movie_category_id_seq OWNER TO postgres;

--
-- Name: movie_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.movie_category_id_seq OWNED BY public.movie_category.movie_category_id;


--
-- Name: paragraph; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paragraph (
    paragraph_id integer NOT NULL,
    paragraph_content text,
    blog_id integer,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_delete boolean DEFAULT false,
    delete_date timestamp with time zone,
    update_date timestamp with time zone
);


ALTER TABLE public.paragraph OWNER TO postgres;

--
-- Name: paragraph_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paragraph_image (
    image_id integer NOT NULL,
    image_link character varying,
    paragraph_id integer,
    created_date time with time zone DEFAULT CURRENT_TIMESTAMP,
    is_deleted boolean DEFAULT false,
    deleted_date timestamp with time zone,
    update_date timestamp with time zone
);


ALTER TABLE public.paragraph_image OWNER TO postgres;

--
-- Name: paragraph_image_image_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paragraph_image_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.paragraph_image_image_id_seq OWNER TO postgres;

--
-- Name: paragraph_image_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paragraph_image_image_id_seq OWNED BY public.paragraph_image.image_id;


--
-- Name: paragraph_paragraph_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paragraph_paragraph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.paragraph_paragraph_id_seq OWNER TO postgres;

--
-- Name: paragraph_paragraph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paragraph_paragraph_id_seq OWNED BY public.paragraph.paragraph_id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    role_id integer NOT NULL,
    role_name character varying(255)
);


ALTER TABLE public.role OWNER TO postgres;

--
-- Name: role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.role_role_id_seq OWNER TO postgres;

--
-- Name: role_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_role_id_seq OWNED BY public.role.role_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    user_name character varying(255) DEFAULT ('user'::text || to_char(CURRENT_TIMESTAMP, 'YYYYMMDDHH24MISS'::text)),
    password character varying(255),
    email character varying(255),
    role_id integer NOT NULL,
    last_visit timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    avatar_link text,
    is_banned boolean,
    provider_id character varying,
    is_enabled boolean,
    banned_date timestamp with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: blog blog_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog ALTER COLUMN blog_id SET DEFAULT nextval('public.blog_blog_id_seq'::regclass);


--
-- Name: blog_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_category ALTER COLUMN id SET DEFAULT nextval('public.blog_category_id_seq'::regclass);


--
-- Name: blog_upvote blog_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_upvote ALTER COLUMN blog_id SET DEFAULT nextval('public.blog_upvote_blog_id_seq'::regclass);


--
-- Name: blog_upvote user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_upvote ALTER COLUMN user_id SET DEFAULT nextval('public.blog_upvote_user_id_seq'::regclass);


--
-- Name: blogtag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blogtag ALTER COLUMN id SET DEFAULT nextval('public.blogtag_id_seq'::regclass);


--
-- Name: comment comment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment ALTER COLUMN comment_id SET DEFAULT nextval('public.comment_id_seq'::regclass);


--
-- Name: movie_category movie_category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movie_category ALTER COLUMN movie_category_id SET DEFAULT nextval('public.movie_category_id_seq'::regclass);


--
-- Name: paragraph paragraph_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paragraph ALTER COLUMN paragraph_id SET DEFAULT nextval('public.paragraph_paragraph_id_seq'::regclass);


--
-- Name: paragraph_image image_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paragraph_image ALTER COLUMN image_id SET DEFAULT nextval('public.paragraph_image_image_id_seq'::regclass);


--
-- Name: role role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role ALTER COLUMN role_id SET DEFAULT nextval('public.role_role_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: blog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog (blog_id, title, blog_thumbnail, create_date, is_deleted, deleted_date, update_date, category_id, tag_id, caption, youtube_link) FROM stdin;
\.
COPY public.blog (blog_id, title, blog_thumbnail, create_date, is_deleted, deleted_date, update_date, category_id, tag_id, caption, youtube_link) FROM '$$PATH$$/4917.dat';

--
-- Data for Name: blog_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_category (id, name) FROM stdin;
\.
COPY public.blog_category (id, name) FROM '$$PATH$$/4929.dat';

--
-- Data for Name: blog_movie_catgory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_movie_catgory (blog_id, movie_category_id, create_date) FROM stdin;
\.
COPY public.blog_movie_catgory (blog_id, movie_category_id, create_date) FROM '$$PATH$$/4934.dat';

--
-- Data for Name: blog_upvote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_upvote (blog_id, user_id, create_date) FROM stdin;
\.
COPY public.blog_upvote (blog_id, user_id, create_date) FROM '$$PATH$$/4926.dat';

--
-- Data for Name: blogtag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blogtag (id, name, create_date, is_delete, delete_date, updated_date) FROM stdin;
\.
COPY public.blogtag (id, name, create_date, is_delete, delete_date, updated_date) FROM '$$PATH$$/4931.dat';

--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment (user_id, content, create_date, is_root, blog_id, comment_rep_id, comment_id, is_delete, delete_date, update_date) FROM stdin;
\.
COPY public.comment (user_id, content, create_date, is_root, blog_id, comment_rep_id, comment_id, is_delete, delete_date, update_date) FROM '$$PATH$$/4923.dat';

--
-- Data for Name: comment_upvote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comment_upvote (user_id, comment_id, create_date) FROM stdin;
\.
COPY public.comment_upvote (user_id, comment_id, create_date) FROM '$$PATH$$/4927.dat';

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
\.
COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM '$$PATH$$/4915.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/4914.dat';

--
-- Data for Name: movie_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movie_category (movie_category_id, catogory_name, create_date, updated_date, delete_date, is_deleted) FROM stdin;
\.
COPY public.movie_category (movie_category_id, catogory_name, create_date, updated_date, delete_date, is_deleted) FROM '$$PATH$$/4933.dat';

--
-- Data for Name: paragraph; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paragraph (paragraph_id, paragraph_content, blog_id, create_date, is_delete, delete_date, update_date) FROM stdin;
\.
COPY public.paragraph (paragraph_id, paragraph_content, blog_id, create_date, is_delete, delete_date, update_date) FROM '$$PATH$$/4919.dat';

--
-- Data for Name: paragraph_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paragraph_image (image_id, image_link, paragraph_id, created_date, is_deleted, deleted_date, update_date) FROM stdin;
\.
COPY public.paragraph_image (image_id, image_link, paragraph_id, created_date, is_deleted, deleted_date, update_date) FROM '$$PATH$$/4921.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role (role_id, role_name) FROM stdin;
\.
COPY public.role (role_id, role_name) FROM '$$PATH$$/4913.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, user_name, password, email, role_id, last_visit, avatar_link, is_banned, provider_id, is_enabled, banned_date) FROM stdin;
\.
COPY public.users (user_id, user_name, password, email, role_id, last_visit, avatar_link, is_banned, provider_id, is_enabled, banned_date) FROM '$$PATH$$/4911.dat';

--
-- Name: blog_blog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_blog_id_seq', 26, true);


--
-- Name: blog_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_category_id_seq', 3, true);


--
-- Name: blog_upvote_blog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_upvote_blog_id_seq', 1, false);


--
-- Name: blog_upvote_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_upvote_user_id_seq', 1, false);


--
-- Name: blogtag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blogtag_id_seq', 6, true);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comment_id_seq', 126, true);


--
-- Name: movie_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.movie_category_id_seq', 12, true);


--
-- Name: paragraph_image_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paragraph_image_image_id_seq', 15, true);


--
-- Name: paragraph_paragraph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paragraph_paragraph_id_seq', 24, true);


--
-- Name: role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_role_id_seq', 3, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 56, true);


--
-- Name: blog_category blog_category_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_category
    ADD CONSTRAINT blog_category_pk PRIMARY KEY (id);


--
-- Name: blog_movie_catgory blog_movie_catgory_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_movie_catgory
    ADD CONSTRAINT blog_movie_catgory_pk PRIMARY KEY (blog_id, movie_category_id);


--
-- Name: blog blog_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog
    ADD CONSTRAINT blog_pk PRIMARY KEY (blog_id);


--
-- Name: blogtag blog_tag_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blogtag
    ADD CONSTRAINT blog_tag_pk PRIMARY KEY (id);


--
-- Name: blog_upvote blog_upvote_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_upvote
    ADD CONSTRAINT blog_upvote_pk PRIMARY KEY (blog_id, user_id);


--
-- Name: comment comment_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pk PRIMARY KEY (comment_id);


--
-- Name: comment_upvote comment_upvote_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment_upvote
    ADD CONSTRAINT comment_upvote_pk PRIMARY KEY (user_id, comment_id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: movie_category movie_category_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movie_category
    ADD CONSTRAINT movie_category_pk PRIMARY KEY (movie_category_id);


--
-- Name: paragraph_image paragraph_image_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paragraph_image
    ADD CONSTRAINT paragraph_image_pk PRIMARY KEY (image_id);


--
-- Name: paragraph paragraphql_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paragraph
    ADD CONSTRAINT paragraphql_pk PRIMARY KEY (paragraph_id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (user_name);


--
-- Name: blog_movie_catgory blog_movie_catgory_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_movie_catgory
    ADD CONSTRAINT blog_movie_catgory_fk FOREIGN KEY (movie_category_id) REFERENCES public.movie_category(movie_category_id);


--
-- Name: blog_movie_catgory blog_movie_catgory_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_movie_catgory
    ADD CONSTRAINT blog_movie_catgory_fk_1 FOREIGN KEY (blog_id) REFERENCES public.blog(blog_id);


--
-- Name: blog blog_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog
    ADD CONSTRAINT blog_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.blogtag(id);


--
-- Name: blog_upvote blog_upvote_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_upvote
    ADD CONSTRAINT blog_upvote_fk FOREIGN KEY (blog_id) REFERENCES public.blog(blog_id);


--
-- Name: blog_upvote blog_upvote_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_upvote
    ADD CONSTRAINT blog_upvote_fk_1 FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: comment comment_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_fk FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: comment comment_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_fk_1 FOREIGN KEY (blog_id) REFERENCES public.blog(blog_id);


--
-- Name: comment_upvote comment_upvote_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment_upvote
    ADD CONSTRAINT comment_upvote_fk FOREIGN KEY (comment_id) REFERENCES public.comment(comment_id);


--
-- Name: comment_upvote comment_upvote_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment_upvote
    ADD CONSTRAINT comment_upvote_fk_1 FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: blog fk_blog_category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog
    ADD CONSTRAINT fk_blog_category FOREIGN KEY (category_id) REFERENCES public.blog_category(id);


--
-- Name: comment fk_reply_to; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT fk_reply_to FOREIGN KEY (comment_rep_id) REFERENCES public.comment(comment_id);


--
-- Name: users fk_user_role; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES public.role(role_id);


--
-- Name: paragraph paragraph_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paragraph
    ADD CONSTRAINT paragraph_fk FOREIGN KEY (blog_id) REFERENCES public.blog(blog_id);


--
-- Name: paragraph_image paragraph_image_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paragraph_image
    ADD CONSTRAINT paragraph_image_fk FOREIGN KEY (paragraph_id) REFERENCES public.paragraph(paragraph_id);


--
-- PostgreSQL database dump complete
--

